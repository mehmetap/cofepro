# CoffeeOrder Pro — ilk çalışan prototip (v0.1)

## Android
Android Studio > Open > `CoffeeOrderPro` klasörünü açın. JDK 17 ve Android SDK 35 gerekir. Gradle senkronizasyonundan sonra Run yapın. Kotlin + XML uygulaması sipariş tutarını hesaplar ve sipariş özetini gösterir. Paket adı `com.example.coffeeorderpro`.

## QR web menü
`web/index.html` dosyasını bir HTTPS statik hosting'e (GitHub Pages / Netlify vb.) yayınlayın. Ardından her masa için yayınlanmış URL'ye `?table=1`, `?table=2` vb. ekleyin ve **bu URL'leri** QR koduna dönüştürün. Örnek: `https://SIZIN-ALAN-ADINIZ.example/menu/?table=5`. Gerçek bir yayın URL'si henüz tanımlanmadığı için QR görseli üretilmedi. Yerel test: `python -m http.server 8000 --directory web`, sonra `http://localhost:8000/?table=5`.

## Mevcut sınırlar
- Android ve web uygulaması birbirinden bağımsız çalışan prototiplerdir.
- Siparişler sunucuya gönderilmez, kaydedilmez, işletme paneline düşmez.
- Gerçek zamanlı sipariş, Firebase/Room, kimlik doğrulama, ödeme ve QR kod üretimi henüz eklenmedi.
- Ürün fiyatları örnek değerlerdir.
- Derleme ve cihaz testleri bu ortamda yapılmadı.

## Sonraki adım
Ortak backend, sipariş API'si, yönetici yetkileri, veri doğrulama, durum takibi ve masa QR üretimi.
